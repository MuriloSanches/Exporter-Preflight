"""Testes que rodam fora do Maya (dublês no lugar de maya.cmds e do SceneContext).

    python -I -m unittest discover -s tests -v
"""
import contextlib
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "musanches", "python"))

from musanches_exporter.checks import ALL_CHECKS  # noqa: E402
from musanches_exporter.checks.blendshapes import BlendShapeOrderCheck  # noqa: E402
from musanches_exporter.checks.geometry import FacesCheck  # noqa: E402
from musanches_exporter.checks.materials import ShaderTypeCheck  # noqa: E402
from musanches_exporter.checks.skeleton import (  # noqa: E402
    MaxInfluencesCheck, RootTransformCheck, SingleRootCheck)
from musanches_exporter.checks.units_axes import UnitsCheck  # noqa: E402
from musanches_exporter.checks.uvs import UVSetsCheck  # noqa: E402
from musanches_exporter.core import fbx_reader  # noqa: E402
from musanches_exporter.core.check import Check, Severity  # noqa: E402
from musanches_exporter.core.profile import Profile, available_profiles, load_profile  # noqa: E402
from musanches_exporter.core.runner import Runner  # noqa: E402
from musanches_exporter.maya_adapter.scene import ShaderInfo  # noqa: E402


class FakeCmds(object):
    def __init__(self, unit="cm", up="y", joints=None, history=None, node_types=None):
        self.unit, self.up = unit, up
        self.joints = joints or {}
        self.history = history or []
        self.node_types = node_types or {}
        self.calls = []

    def ls(self, *a, **k):
        return ["lambert1", "openPBR_shader1"] if k.get("defaultNodes") else []

    def currentUnit(self, query=False, linear=False):
        if query:
            return self.unit
        self.calls.append(("currentUnit", linear))

    def upAxis(self, query=False, axis=False):
        return self.up

    def listRelatives(self, node, parent=False, type=None, **kw):
        p = self.joints[node]["parent"]
        return [p] if p else None

    def xform(self, node, query=False, worldSpace=False, translation=False):
        return list(self.joints[node]["t"])

    def getAttr(self, plug):
        node, attr = plug.rsplit(".", 1)
        return [tuple(self.joints[node][{"rotate": "r", "scale": "s"}[attr]])]

    def listHistory(self, node, **kw):
        return list(self.history)

    def nodeType(self, node, **kw):
        return self.node_types[node]


class FakeCtx(object):
    def __init__(self, cmds=None, joints=None, shapes=None, **kw):
        self.cmds = cmds or FakeCmds()
        self._joints = joints if joints is not None else list(self.cmds.joints)
        self._shapes = shapes or []
        self.kw = kw

    def joints(self): return list(self._joints)
    def mesh_shapes(self): return list(self._shapes)
    def transform_of(self, shape): return shape.replace("Shape", "")
    def shader_info(self): return self.kw.get("shaders", [])
    def uv_sets(self, shape): return self.kw["uv"][shape]
    def face_stats(self, shape, zero_tol=1e-6): return self.kw["faces"][shape]
    def influence_stats(self, shape, limit): return self.kw.get("influences")
    @contextlib.contextmanager
    def undo_chunk(self): yield


def joint(parent=None, t=(0, 0, 0), r=(0, 0, 0), s=(1, 1, 1)):
    return {"parent": parent, "t": t, "r": r, "s": s}


UNREAL = load_profile("unreal5")
UNITY = load_profile("unity")
SUBSTANCE = load_profile("substance")


class ProfileTests(unittest.TestCase):
    def test_builtin_profiles_listed(self):
        self.assertTrue({"unreal5", "unity", "substance"} <= set(available_profiles()))

    def test_merge_keeps_defaults(self):
        p = Profile({"name": "x", "rig": {"max_influences": 2}})
        self.assertEqual(p.section("rig")["max_influences"], 2)
        self.assertTrue(p.section("rig")["single_root"])
        self.assertEqual(p.units, "cm")

    def test_profiles_differ(self):
        self.assertEqual(UNREAL.up_axis, "z")
        self.assertEqual(UNITY.up_axis, "y")
        self.assertTrue(SUBSTANCE.section("uv")["allow_udim"])


class CheckLogicTests(unittest.TestCase):
    def test_units_wrong_and_fix(self):
        cmds = FakeCmds(unit="m")
        ctx = FakeCtx(cmds)
        check = UnitsCheck(UNREAL)
        issues = check.run(ctx)
        self.assertEqual(len(issues), 1)
        self.assertTrue(check.fix(ctx, issues[0]))
        self.assertEqual(cmds.calls, [("currentUnit", "cm")])
        self.assertEqual(UnitsCheck(UNREAL).run(FakeCtx(FakeCmds(unit="cm"))), [])

    def test_multiple_roots_is_error(self):
        cmds = FakeCmds(joints={"|a": joint(), "|b": joint(), "|a|c": joint(parent="|a")})
        issues = SingleRootCheck(UNREAL).run(FakeCtx(cmds))
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0].severity, Severity.ERROR)
        self.assertEqual(sorted(issues[0].nodes), ["|a", "|b"])

    def test_root_rotation_and_origin(self):
        cmds = FakeCmds(joints={"|root": joint(t=(0, 5, 0), r=(90, 0, 0))})
        issues = RootTransformCheck(UNREAL).run(FakeCtx(cmds))
        self.assertEqual(len(issues), 2)
        # Unity não exige root na origem, só rotação zero
        self.assertEqual(len(RootTransformCheck(UNITY).run(FakeCtx(cmds))), 1)

    def test_shader_type(self):
        shaders = [ShaderInfo("|aShape", "sg1", "mat_ok", "lambert"),
                   ShaderInfo("|aShape", "sg2", "mat_ai", "aiStandardSurface"),
                   ShaderInfo("|bShape", "sg2", "mat_ai", "aiStandardSurface")]
        issues = ShaderTypeCheck(UNREAL).run(FakeCtx(shaders=shaders))
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0].nodes, ["mat_ai"])
        self.assertTrue(issues[0].fixable)

    def test_uv_sets(self):
        uv = {
            "|aShape": [{"name": "map1", "count": 8, "bbox": ((0, 1), (0, 1))},
                        {"name": "map2", "count": 0, "bbox": None}],
            "|bShape": [{"name": "map1", "count": 8, "bbox": ((0, 2), (0, 1))}],
            "|cShape": [{"name": "map1", "count": 0, "bbox": None}],
        }
        ctx = FakeCtx(shapes=["|aShape", "|bShape", "|cShape"], uv=uv)
        issues = UVSetsCheck(UNREAL).run(ctx)
        msgs = " | ".join(i.message for i in issues)
        self.assertIn("vazio", msgs)          # a: UV set vazio
        self.assertIn("fora de 0-1", msgs)    # b: UVs além de 1
        self.assertIn("não tem UVs", msgs)    # c: sem UVs
        # no perfil do Substance, UDIM é permitido
        ctx_b = FakeCtx(shapes=["|bShape"], uv={"|bShape": uv["|bShape"]})
        self.assertFalse(any("fora de 0-1" in i.message for i in UVSetsCheck(SUBSTANCE).run(ctx_b)))

    def test_faces(self):
        faces = {"|aShape": {"zero_area": ["|aShape.f[3]"], "ngons": ["|aShape.f[7]"]}}
        issues = FacesCheck(UNREAL).run(FakeCtx(shapes=["|aShape"], faces=faces))
        by_sev = {i.severity for i in issues}
        self.assertIn(Severity.WARNING, by_sev)
        self.assertIn(Severity.INFO, by_sev)  # n-gon vira INFO: o perfil triangula

    def test_influences(self):
        ctx = FakeCtx(shapes=["|aShape"], influences={"over": 12, "max": 6, "vertices": 100})
        issues = MaxInfluencesCheck(UNITY).run(ctx)
        self.assertEqual(len(issues), 1)
        self.assertIn("12", issues[0].message)

    def test_blendshape_order(self):
        # histórico: blendShape mais perto da malha que o skin => pós-deformação
        cmds = FakeCmds(history=["blendShape1", "skinCluster1"],
                        node_types={"blendShape1": "blendShape", "skinCluster1": "skinCluster"})
        issues = BlendShapeOrderCheck(UNREAL).run(FakeCtx(cmds, shapes=["|aShape"]))
        self.assertEqual(len(issues), 1)
        cmds_ok = FakeCmds(history=["skinCluster1", "blendShape1"],
                           node_types={"blendShape1": "blendShape", "skinCluster1": "skinCluster"})
        self.assertEqual(BlendShapeOrderCheck(UNREAL).run(FakeCtx(cmds_ok, shapes=["|aShape"])), [])


class RunnerTests(unittest.TestCase):
    def test_check_ids_unique_and_documented(self):
        ids = [c.id for c in ALL_CHECKS]
        self.assertEqual(len(ids), len(set(ids)))
        for c in ALL_CHECKS:
            self.assertTrue(c.title and c.category, c.id)

    def test_disabled_checks_in_substance_profile_exist(self):
        ids = {c.id for c in ALL_CHECKS}
        for cid in SUBSTANCE.disabled_checks:
            self.assertIn(cid, ids)
        runner = Runner(SUBSTANCE, ALL_CHECKS)
        self.assertFalse(any(c.id.startswith("rig.") for c in runner.checks))

    def test_broken_check_does_not_stop_the_others(self):
        class Boom(Check):
            id, category, title = "boom", "Teste", "Quebra"
            def run(self, ctx): raise ValueError("kaput")

        class Fine(Check):
            id, category, title = "fine", "Teste", "Ok"
            def run(self, ctx): return [self.issue(Severity.INFO, "ok")]

        report = Runner(UNREAL, [Boom, Fine]).run(FakeCtx())
        self.assertEqual(len(report.issues), 2)
        self.assertTrue(report.has_errors)
        self.assertIn("kaput", report.issues[0].message)

    def test_report_outputs(self):
        class One(Check):
            id, category, title = "one", "Teste", "Um"
            def run(self, ctx): return [self.issue(Severity.WARNING, "<b>x</b>", nodes=["|n"])]

        report = Runner(UNREAL, [One]).run(FakeCtx(), scope="Seleção")
        self.assertEqual(report.counts(), {"erro": 0, "aviso": 1, "info": 0})
        self.assertIn("&lt;b&gt;", report.to_html())  # HTML escapado
        with tempfile.TemporaryDirectory() as tmp:
            for name in ("r.html", "r.json"):
                path = report.save(os.path.join(tmp, name))
                self.assertTrue(os.path.getsize(path) > 0)

    def test_fix_runs_inside_undo_chunk(self):
        cmds = FakeCmds(unit="m")
        ctx = FakeCtx(cmds)
        runner = Runner(UNREAL, [UnitsCheck])
        issue = runner.run(ctx).issues[0]
        self.assertTrue(runner.fix(ctx, issue))
        self.assertEqual(cmds.calls, [("currentUnit", "cm")])
        issue.fixable = False  # item não corrigível nunca chega ao check
        self.assertFalse(runner.fix(ctx, issue))


FBX_SAMPLE = '''; FBX 7.5.0 project file
GlobalSettings:  {
\tVersion: 1000
\tProperties70:  {
\t\tP: "UpAxis", "int", "Integer", "",2
\t\tP: "UnitScaleFactor", "double", "Number", "",1
\t}
}
Objects:  {
\tGeometry: 111, "Geometry::pCubeShape1", "Mesh" {
\t\tVertices: *24 { a: 0 }
\t\tLayerElementNormal: 0 {
\t\t}
\t\tLayerElementTangent: 0 {
\t\t}
\t\tLayerElementUV: 0 {
\t\t}
\t\tLayerElementUV: 1 {
\t\t}
\t}
\tGeometry: 112, "Geometry::pPlaneShape1", "Mesh" {
\t\tLayerElementNormal: 0 {
\t\t}
\t}
\tModel: 200, "Model::root", "LimbNode" {
\t}
\tModel: 201, "Model::spine", "LimbNode" {
\t}
\tDeformer: 300, "Deformer::skinCluster1", "Skin" {
\t}
\tDeformer: 301, "SubDeformer::smile", "BlendShapeChannel" {
\t}
}
'''


class FbxReaderTests(unittest.TestCase):
    def test_parse(self):
        s = fbx_reader.parse_ascii(FBX_SAMPLE)
        self.assertEqual(s.up_axis, "z")
        self.assertEqual(s.unit_scale_factor, 1.0)
        self.assertEqual(s.meshes, 2)
        self.assertEqual(s.uv_layers, [2, 0])
        self.assertEqual(s.tangents, [True, False])
        self.assertEqual((s.limb_nodes, s.skin_deformers, s.blendshape_channels), (2, 1, 1))

    def test_verify_against_profile(self):
        s = fbx_reader.parse_ascii(FBX_SAMPLE)
        ids = [i.check_id for i in fbx_reader.verify_summary(s, UNREAL)]
        self.assertIn("verify.uv", ids)        # a segunda malha não tem UV
        self.assertIn("verify.tangents", ids)  # a segunda malha não tem tangentes
        self.assertNotIn("verify.up_axis", ids)
        ids_unity = [i.check_id for i in fbx_reader.verify_summary(s, UNITY)]
        self.assertIn("verify.up_axis", ids_unity)  # FBX saiu Z-up, perfil pede Y-up

    def test_binary_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "b.fbx")
            with open(path, "wb") as fh:
                fh.write(b"Kaydara FBX Binary  \x00\x1a\x00" + b"\x00" * 64)
            s = fbx_reader.read_fbx(path)
            self.assertFalse(s.is_ascii)
            self.assertTrue(s.error)


if __name__ == "__main__":
    unittest.main()
