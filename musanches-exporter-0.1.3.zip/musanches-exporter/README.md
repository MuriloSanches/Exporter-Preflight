# Musanches Export Preflight

Plugin para Maya (PySide6 no Maya 2025+, PySide2 no Maya 2022–2024) que **valida, corrige, exporta e confere** FBX
para **Unreal, Unity e Substance Painter**, a partir de perfis de destino.

> Versão 0.1.3. Testada no Maya 2026.3 (PySide6): módulo, menu, janela, os 3 perfis, correções e
> export FBX. Ainda não testados: CLI (mayapy), UDIM/texture sets reais do Substance e o perfil
> Unreal num rig completo. O núcleo também tem testes automatizados fora do Maya. Veja "Limitações".

## Instalação

1. Copie **`Musanches.mod`** e a pasta **`musanches/`** para a pasta de módulos do Maya:
   - Windows: `Documentos\maya\modules\`
   - macOS: `~/Library/Preferences/Autodesk/maya/modules/`
   - Linux: `~/maya/modules/`
2. Reinicie o Maya. O menu **Musanches** aparece na barra principal.
   Se o menu não aparecer, abra pelo Script Editor (Python):
   ```python
   import musanches_exporter
   musanches_exporter.show()
   ```

## Uso

1. Escolha o **perfil** (Unreal Engine 5, Unity ou Substance Painter) e o **escopo** (Seleção ou Cena inteira).
2. **Verificar**: a lista agrupa os problemas por categoria. Duplo clique seleciona os objetos no Maya.
3. **Corrigir selecionados / Corrigir tudo**: itens marcados `[corrigível]`. Cada correção é um undo chunk (Ctrl+Z desfaz).
4. **Exportar FBX…**: aplica as opções do perfil ao exportador FBX e, ao final, exporta uma cópia ASCII temporária
   para conferir o que foi realmente gravado (eixo, unidade, UVs, tangentes, skin).
5. **Salvar relatório…**: HTML ou JSON.

Por script:
```python
import musanches_exporter as mx
report = mx.check("unity", selection_only=True)
print(report.to_json())
```

Em lote (mayapy), útil para validar entregas de alunos ou rodar em pipeline:
```
mayapy -m musanches_exporter.cli cena.ma --profile unreal5 --report relatorio.html
```
Código de saída 1 quando há erros.

## O que é verificado

| Categoria | Verificação | Corrige? |
|---|---|---|
| Cena | Unidade linear; eixo para cima | unidade |
| Geometria | Histórico; transformações não congeladas e escala negativa; faces de área zero; n-gons | histórico, transformações |
| UVs | Sem UVs; UV sets vazios; mais sets que o perfil; lightmap; UVs fora de 0–1 (exceto UDIM) | UV sets vazios |
| Materiais | Shaders que o FBX não leva (ex.: Arnold); texturas inexistentes | troca por Lambert com o mesmo nome |
| Rig | Root único; root na origem e sem rotação; escala dos joints; influências por vértice; bind pose; constraints | — |
| Blend shapes | Blend shape avaliado depois do skin; inbetweens | — |
| Nomes | Padrão de nomes de malhas, joints e materiais | renomeia |
| Pós-export | Eixo, UnitScaleFactor, UVs, normais, tangentes e skin no FBX gravado | — |

## Perfis

Ficam em `musanches/python/musanches_exporter/profiles/*.json`. Para criar os seus, coloque arquivos `.json`
numa pasta e aponte a variável de ambiente `MUSANCHES_PROFILES` para ela (vários caminhos separados por `;` no Windows
ou `:` no macOS/Linux). Campos que você omitir herdam os padrões.

```json
{
  "name": "Meu projeto",
  "units": "cm", "up_axis": "z",
  "fbx": {"convert_unit": "cm", "up_axis": "z", "triangulate": true, "tangents": true},
  "uv": {"max_sets": 2, "allow_udim": false},
  "rig": {"max_influences": 8, "root_at_origin": true},
  "disabled_checks": ["rig.bind_pose"]
}
```

## Estrutura

```
Musanches.mod
musanches/
├── scripts/userSetup.py            # cria o menu ao abrir o Maya
└── python/musanches_exporter/
    ├── core/                       # Python puro: Check, Issue, Profile, Runner, Report, leitor de FBX ASCII
    ├── maya_adapter/               # única camada com maya.cmds / OpenMaya 2.0 / MEL
    ├── checks/                     # uma classe por verificação (run + fix opcional)
    ├── profiles/                   # unreal5.json, unity.json, substance.json
    ├── ui/                         # janela dockável (PySide6/PySide2)
    └── cli.py                      # modo batch
tests/test_core.py                  # roda fora do Maya
```

Para adicionar uma verificação: crie uma classe que herda de `Check` em `checks/`, defina `id`, `category`, `title`,
implemente `run(ctx)` (e `fix(ctx, issue)` se for seguro) e registre em `checks/__init__.py`.

## Testes

```
python -I -m unittest discover -s tests -v
```

## Limitações da versão 0.1.3

- **Não foi executado dentro do Maya.** Os nomes dos comandos MEL do plugin FBX (`FBXExport*`) e as chamadas de
  OpenMaya podem exigir ajuste conforme a versão do Maya.
- A exportação usa a seleção ou a cena diretamente: ainda **não há cópia "proxy"** para aplicar correções sem tocar
  na cena de trabalho. As correções usam undo chunk.
- Não implementados: consistência de orientação dos joints, sobreposição de UV no lightmap, vértices sobrepostos,
  conversão completa de materiais (só cor base/textura de cor viram Lambert), checagem de UDIM por tile.
- A lista de problemas vem de relatos de fóruns e da documentação da Epic e da Autodesk; algumas dicas podem
  estar defasadas na UE5 com Interchange.
- A verificação de texturas olha a cena toda, não só o escopo escolhido.
