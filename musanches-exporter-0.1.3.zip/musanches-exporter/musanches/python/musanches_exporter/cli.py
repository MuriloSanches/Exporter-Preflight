"""Modo batch (mayapy): valida cenas em lote e, se pedido, exporta.

    mayapy -m musanches_exporter.cli cena.ma --profile unreal5 --report rel.html
    mayapy -m musanches_exporter.cli cena.ma --profile unity --export saida.fbx

Código de saída: 0 sem erros, 1 com erros na verificação.
"""
from __future__ import annotations

import argparse
import sys


def main(argv=None):
    ap = argparse.ArgumentParser(description="Musanches Export Preflight (batch)")
    ap.add_argument("scene", help="cena .ma/.mb")
    ap.add_argument("--profile", default="unreal5", help="chave do perfil (padrão: unreal5)")
    ap.add_argument("--report", help="salvar relatório (.html ou .json)")
    ap.add_argument("--fix", action="store_true", help="aplicar correções automáticas e reverificar")
    ap.add_argument("--export", help="exportar a cena inteira para este .fbx")
    args = ap.parse_args(argv)

    import maya.standalone
    maya.standalone.initialize(name="python")
    from maya import cmds

    from .checks import ALL_CHECKS
    from .core.profile import load_profile
    from .core.runner import Runner
    from .maya_adapter import fbx_export
    from .maya_adapter.scene import SceneContext

    cmds.file(args.scene, open=True, force=True)
    profile = load_profile(args.profile)
    runner = Runner(profile, ALL_CHECKS)
    ctx = SceneContext()
    report = runner.run(ctx, scope="Cena inteira")

    if args.fix:
        skipped = set()
        for _ in range(50):
            todo = [i for i in report.issues if i.fixable and i.signature() not in skipped]
            if not todo:
                break
            if not runner.fix(ctx, todo[0]):
                skipped.add(todo[0].signature())
            ctx = SceneContext()
            report = runner.run(ctx, scope="Cena inteira")

    counts = report.counts()
    print("[Musanches] %s: %d erro(s), %d aviso(s), %d info"
          % (profile.name, counts["erro"], counts["aviso"], counts["info"]))
    for issue in report.issues:
        print("  [%s] %s: %s" % (issue.severity.label, issue.category, issue.message))

    if args.export and not report.has_errors:
        fbx_export.export_fbx(ctx, args.export, profile, selection=False)
        print("[Musanches] exportado: %s" % args.export)
    elif args.export:
        print("[Musanches] exportação ignorada: há erros.")

    if args.report:
        report.save(args.report)

    code = 1 if report.has_errors else 0
    maya.standalone.uninitialize()
    return code


if __name__ == "__main__":
    sys.exit(main())
