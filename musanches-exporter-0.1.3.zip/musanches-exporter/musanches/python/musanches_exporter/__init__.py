"""Musanches Export Preflight: valida, corrige, exporta e confere FBX do Maya
para Unreal, Unity e Substance Painter."""

__version__ = "0.1.3"


def show():
    """Abre a janela (precisa do Maya com interface)."""
    from .ui.main_window import show_window
    return show_window()


def check(profile="unreal5", selection_only=False):
    """Roda as verificações por script e devolve um Report.

    >>> import musanches_exporter as mx
    >>> report = mx.check("unity", selection_only=True)
    >>> print(report.to_json())
    """
    from maya import cmds
    from .checks import ALL_CHECKS
    from .core.profile import load_profile
    from .core.runner import Runner
    from .maya_adapter.scene import SceneContext

    roots = []
    if selection_only:
        # componentes viram o objeto; shapes viram o transform; nós que não são objetos são ignorados
        for node in cmds.ls(selection=True, objectsOnly=True, long=True) or []:
            if not cmds.objectType(node, isAType="dagNode"):
                continue
            if cmds.objectType(node, isAType="shape"):
                node = (cmds.listRelatives(node, parent=True, fullPath=True) or [node])[0]
            if node not in roots:
                roots.append(node)
    scope = "Seleção" if selection_only else "Cena inteira"
    return Runner(load_profile(profile), ALL_CHECKS).run(SceneContext(roots=roots), scope=scope)
