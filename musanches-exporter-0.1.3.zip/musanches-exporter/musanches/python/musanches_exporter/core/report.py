"""Relatório de uma execução: contagens, JSON e HTML."""
from __future__ import annotations

import datetime
import html
import json
from dataclasses import dataclass, field
from typing import List

from .check import Issue, Severity


@dataclass
class Report:
    profile_name: str
    issues: List[Issue] = field(default_factory=list)
    scope: str = ""
    created: str = field(
        default_factory=lambda: datetime.datetime.now().isoformat(timespec="seconds")
    )

    def counts(self):
        out = {"erro": 0, "aviso": 0, "info": 0}
        for issue in self.issues:
            out[issue.severity.label] += 1
        return out

    @property
    def has_errors(self):
        return any(i.severity == Severity.ERROR for i in self.issues)

    def to_dict(self):
        return {
            "profile": self.profile_name,
            "scope": self.scope,
            "created": self.created,
            "counts": self.counts(),
            "issues": [i.to_dict() for i in self.issues],
        }

    def to_json(self):
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

    def to_html(self):
        colors = {"erro": "#c0392b", "aviso": "#d68910", "info": "#2471a3"}
        rows = []
        ordered = sorted(self.issues, key=lambda i: (-int(i.severity), i.category))
        for i in ordered:
            label = i.severity.label
            nodes = ", ".join(i.nodes[:20]) + (" …" if len(i.nodes) > 20 else "")
            rows.append(
                "<tr><td style='color:%s;font-weight:bold'>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                % (
                    colors[label], label.upper(), html.escape(i.category),
                    html.escape(i.message), html.escape(nodes), html.escape(i.hint),
                )
            )
        c = self.counts()
        return (
            "<!doctype html><html lang='pt-BR'><meta charset='utf-8'>"
            "<title>Musanches Export Preflight</title>"
            "<style>body{font-family:sans-serif;margin:2rem}table{border-collapse:collapse;width:100%%}"
            "td,th{border:1px solid #ccc;padding:6px 8px;text-align:left;vertical-align:top}"
            "th{background:#f2f2f2}</style>"
            "<h1>Musanches Export Preflight</h1>"
            "<p>Perfil: <b>%s</b> &middot; Escopo: %s &middot; %s</p>"
            "<p>%d erro(s), %d aviso(s), %d info</p>"
            "<table><tr><th>Nível</th><th>Categoria</th><th>Mensagem</th><th>Objetos</th><th>Dica</th></tr>%s</table></html>"
            % (
                html.escape(self.profile_name), html.escape(self.scope or "-"), self.created,
                c["erro"], c["aviso"], c["info"], "".join(rows),
            )
        )

    def save(self, path):
        """Salva em .html, .json (ou .json por padrão)."""
        text = self.to_html() if path.lower().endswith((".html", ".htm")) else self.to_json()
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
        return path
