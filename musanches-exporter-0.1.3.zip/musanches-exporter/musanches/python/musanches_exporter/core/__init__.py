"""Núcleo do Musanches Export Preflight: Python puro, sem importar maya."""
