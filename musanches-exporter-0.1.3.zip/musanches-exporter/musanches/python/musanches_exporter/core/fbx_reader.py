"""Leitura mínima de FBX ASCII para conferir o que realmente foi gravado.

O FBX binário não é lido aqui: o exportador gera uma cópia ASCII só para a
verificação (veja maya_adapter.fbx_export.verify_export).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional

from .check import Issue, Severity

_OBJ = re.compile(r'^\t(\w+):\s*(-?\d+),\s*"([^"]*)",\s*"([^"]*)"', re.M)
_UP = re.compile(r'"UpAxis",\s*"int",\s*"Integer",\s*"",\s*(-?\d+)')
_UNIT = re.compile(r'"UnitScaleFactor",\s*"double",\s*"Number",\s*"",\s*([-+0-9.eE]+)')
_AXES = {0: "x", 1: "y", 2: "z"}

# Valor de UnitScaleFactor no FBX: 1.0 = centímetro.
UNIT_SCALE = {"mm": 0.1, "cm": 1.0, "dm": 10.0, "m": 100.0, "km": 100000.0, "inch": 2.54, "foot": 30.48}


@dataclass
class FbxSummary:
    path: str = ""
    is_ascii: bool = True
    up_axis: Optional[str] = None
    unit_scale_factor: Optional[float] = None
    meshes: int = 0
    uv_layers: List[int] = field(default_factory=list)   # por malha
    normals: List[bool] = field(default_factory=list)    # por malha
    tangents: List[bool] = field(default_factory=list)   # por malha
    limb_nodes: int = 0
    skin_deformers: int = 0
    blendshape_channels: int = 0
    error: str = ""


def parse_ascii(text, path=""):
    s = FbxSummary(path=path)
    m = _UP.search(text)
    if m:
        s.up_axis = _AXES.get(int(m.group(1)))
    m = _UNIT.search(text)
    if m:
        s.unit_scale_factor = float(m.group(1))

    matches = list(_OBJ.finditer(text))
    for i, om in enumerate(matches):
        cls, subtype = om.group(1), om.group(4)
        if cls == "Geometry" and subtype == "Mesh":
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            seg = text[om.start():end]
            s.meshes += 1
            s.uv_layers.append(seg.count("LayerElementUV:"))
            s.normals.append("LayerElementNormal:" in seg)
            s.tangents.append("LayerElementTangent:" in seg)
        elif cls == "Model" and subtype == "LimbNode":
            s.limb_nodes += 1
        elif cls == "Deformer" and subtype == "Skin":
            s.skin_deformers += 1
        elif cls == "Deformer" and subtype == "BlendShapeChannel":
            s.blendshape_channels += 1
    return s


def read_fbx(path):
    with open(path, "rb") as fh:
        head = fh.read(32)
    if head.startswith(b"Kaydara FBX Binary"):
        return FbxSummary(path=path, is_ascii=False,
                          error="FBX binário: gere uma cópia ASCII para verificar.")
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return parse_ascii(fh.read(), path)


def verify_summary(summary, profile):
    """Compara o FBX gravado com o perfil. Devolve uma lista de Issue."""
    cat = "Pós-export"
    out = []
    if summary.error:
        return [Issue("verify.read", cat, Severity.INFO, summary.error)]

    fbx = profile.fbx
    want_axis = str(fbx.get("up_axis", "")).lower()
    if want_axis and summary.up_axis and summary.up_axis != want_axis:
        out.append(Issue("verify.up_axis", cat, Severity.ERROR,
                         "Eixo para cima no FBX é '%s'; o perfil pede '%s'." % (summary.up_axis, want_axis)))

    want_unit = str(fbx.get("convert_unit", "")).lower()
    want_scale = UNIT_SCALE.get(want_unit)
    if want_scale and summary.unit_scale_factor is not None:
        if abs(summary.unit_scale_factor - want_scale) > 1e-6:
            out.append(Issue("verify.unit", cat, Severity.WARNING,
                             "UnitScaleFactor do FBX é %g; para '%s' o esperado é %g."
                             % (summary.unit_scale_factor, want_unit, want_scale),
                             hint="Confira 'Convert Units To' nas opções do FBX."))

    uv_max = int(profile.section("uv").get("max_sets", 2))
    for idx, n_uv in enumerate(summary.uv_layers):
        if n_uv == 0:
            out.append(Issue("verify.uv", cat, Severity.ERROR, "Malha #%d foi gravada sem UVs." % (idx + 1)))
        elif n_uv > uv_max:
            out.append(Issue("verify.uv", cat, Severity.WARNING,
                             "Malha #%d tem %d UV sets gravados (perfil: até %d)." % (idx + 1, n_uv, uv_max)))

    if fbx.get("tangents") and summary.meshes and not all(summary.tangents):
        out.append(Issue("verify.tangents", cat, Severity.WARNING,
                         "Há malhas sem tangentes/binormais gravadas, embora o perfil peça.",
                         hint="O FBX só grava tangentes em malhas trianguladas; confira a triangulação."))
    if summary.meshes and not all(summary.normals):
        out.append(Issue("verify.normals", cat, Severity.WARNING, "Há malhas sem normais gravadas."))

    if fbx.get("skins") and summary.limb_nodes and not summary.skin_deformers:
        out.append(Issue("verify.skin", cat, Severity.WARNING,
                         "Há joints no FBX, mas nenhum skin deformer foi gravado."))
    return out
