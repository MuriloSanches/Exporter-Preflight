"""Perfis de destino (Unreal, Unity, Substance...) carregados de arquivos JSON."""
from __future__ import annotations

import copy
import json
import os
from collections import OrderedDict

DEFAULTS = {
    "name": "Perfil sem nome",
    "units": "cm",
    "up_axis": "y",
    "fbx": {
        "convert_unit": "cm",
        "up_axis": "y",
        "version": "FBX201800",
        "smoothing_groups": True,
        "tangents": True,
        "triangulate": True,
        "skins": True,
        "shapes": True,
        "constraints": False,
        "input_connections": False,
        "embed_media": False,
        "bake_animation": False,
        "cameras": False,
        "lights": False,
        "ascii": False,
        "verify_after_export": True,
    },
    "naming": {"pattern": r"^[A-Za-z0-9_]+$"},
    "geometry": {"zero_area_tolerance": 1e-6, "transform_tolerance": 1e-4},
    "uv": {
        "max_sets": 2,
        "require_0_1": True,
        "allow_udim": False,
        "want_lightmap_set": True,
    },
    "rig": {
        "single_root": True,
        "root_at_origin": True,
        "root_zero_rotation": True,
        "max_influences": 4,
        "warn_non_unit_scale": True,
    },
    "materials": {
        "allowed": [
            "lambert", "blinn", "phong", "phongE",
            "StingrayPBS", "ShaderfxShader",
        ],
        "check_textures": True,
    },
    "blendshapes": {"warn_inbetweens": True, "require_pre_deformation": True},
    "disabled_checks": [],
}


def _merge(base, over):
    out = copy.deepcopy(base)
    for key, value in (over or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


class Profile(object):
    def __init__(self, data, key="custom"):
        self.key = key
        self.data = _merge(DEFAULTS, data)

    @property
    def name(self):
        return self.data["name"]

    @property
    def units(self):
        return self.data["units"]

    @property
    def up_axis(self):
        return self.data["up_axis"]

    @property
    def fbx(self):
        return self.data["fbx"]

    @property
    def disabled_checks(self):
        return list(self.data.get("disabled_checks", []))

    def section(self, name):
        return self.data.get(name, {})


def profile_dirs():
    """Pasta de perfis do pacote + pastas extras em MUSANCHES_PROFILES."""
    builtin = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "profiles")
    extra = [d for d in os.environ.get("MUSANCHES_PROFILES", "").split(os.pathsep) if d]
    return [builtin] + extra


def available_profiles():
    """Devolve {chave: caminho}. Pastas posteriores sobrescrevem as anteriores."""
    found = OrderedDict()
    for folder in profile_dirs():
        if not os.path.isdir(folder):
            continue
        for fname in sorted(os.listdir(folder)):
            if fname.lower().endswith(".json"):
                found[os.path.splitext(fname)[0]] = os.path.join(folder, fname)
    return found


def load_profile_file(path):
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    return Profile(data, key=os.path.splitext(os.path.basename(path))[0])


def load_profile(key):
    profiles = available_profiles()
    if key not in profiles:
        raise KeyError("Perfil '%s' não encontrado. Disponíveis: %s" % (key, ", ".join(profiles)))
    return load_profile_file(profiles[key])
