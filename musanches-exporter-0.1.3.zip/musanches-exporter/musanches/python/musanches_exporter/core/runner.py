"""Executa as verificações de um perfil e aplica correções."""
from __future__ import annotations

import logging

from .check import Issue, Severity
from .report import Report

log = logging.getLogger("musanches")


class Runner(object):
    def __init__(self, profile, check_classes):
        self.profile = profile
        disabled = set(profile.disabled_checks)
        self.checks = [cls(profile) for cls in check_classes if cls.id not in disabled]
        self._by_id = {c.id: c for c in self.checks}

    def run(self, ctx, scope=""):
        issues = []
        for check in self.checks:
            try:
                issues.extend(check.run(ctx))
            except Exception as exc:  # uma verificação com defeito não derruba as outras
                log.exception("Falha na verificação %s", check.id)
                issues.append(
                    Issue(
                        check.id, check.category, Severity.ERROR,
                        "Falha ao executar '%s': %s" % (check.title or check.id, exc),
                    )
                )
        return Report(profile_name=self.profile.name, issues=issues, scope=scope)

    def fix(self, ctx, issue):
        check = self._by_id.get(issue.check_id)
        if check is None or not issue.fixable:
            return False
        try:
            with ctx.undo_chunk():
                return bool(check.fix(ctx, issue))
        except Exception:
            log.exception("Falha ao corrigir %s", issue.check_id)
            return False
