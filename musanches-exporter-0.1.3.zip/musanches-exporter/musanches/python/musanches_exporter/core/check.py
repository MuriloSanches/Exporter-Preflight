"""Classes base: Severity, Issue e Check."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Dict, List


class Severity(IntEnum):
    INFO = 0
    WARNING = 1
    ERROR = 2

    @property
    def label(self):
        return {0: "info", 1: "aviso", 2: "erro"}[int(self)]


@dataclass
class Issue:
    check_id: str
    category: str
    severity: Severity
    message: str
    nodes: List[str] = field(default_factory=list)
    fixable: bool = False
    hint: str = ""
    data: Dict[str, Any] = field(default_factory=dict)

    def signature(self):
        """Identifica o problema (usado para não repetir correções que falharam)."""
        return (self.check_id, tuple(self.nodes), self.message)

    def to_dict(self):
        return {
            "check": self.check_id,
            "category": self.category,
            "severity": self.severity.label,
            "message": self.message,
            "nodes": list(self.nodes),
            "fixable": self.fixable,
            "hint": self.hint,
        }


class Check(object):
    """Uma verificação. Subclasses definem id/category/title e implementam run().

    run(ctx) devolve uma lista de Issue. fix(ctx, issue) corrige o problema
    (retorna True se conseguiu) e só é chamado quando issue.fixable é True.
    ctx é um SceneContext (ou um dublê nos testes).
    """

    id = "check"
    category = "Geral"
    title = ""

    def __init__(self, profile):
        self.profile = profile

    def run(self, ctx):
        raise NotImplementedError

    def fix(self, ctx, issue):
        return False

    def issue(self, severity, message, nodes=None, fixable=False, hint="", **data):
        return Issue(
            check_id=self.id,
            category=self.category,
            severity=severity,
            message=message,
            nodes=list(nodes or []),
            fixable=fixable,
            hint=hint,
            data=data,
        )
