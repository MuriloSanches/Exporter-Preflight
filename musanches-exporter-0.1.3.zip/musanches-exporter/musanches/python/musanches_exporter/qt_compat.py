"""Importa o Qt do Maya: PySide6 (Maya 2025+) ou PySide2 (Maya 2022-2024)."""
try:
    from PySide6 import QtCore, QtGui, QtWidgets  # noqa: F401
    QT_BINDING = "PySide6"
except ImportError:  # pragma: no cover
    from PySide2 import QtCore, QtGui, QtWidgets  # noqa: F401
    QT_BINDING = "PySide2"
