"""Interface Qt do Musanches Export Preflight."""
