"""Janela dockável do Musanches Export Preflight (PySide6 / PySide2).

Todas as chamadas ao Maya acontecem na thread principal: o maya.cmds não é
thread-safe, então nada aqui usa QThread.
"""
from __future__ import annotations

import os

from maya import cmds
from maya.app.general.mayaMixin import MayaQWidgetDockableMixin

from ..checks import ALL_CHECKS
from ..core.check import Severity
from ..core.profile import available_profiles, load_profile
from ..core.runner import Runner
from ..maya_adapter import fbx_export
from ..maya_adapter.scene import SceneContext
from ..qt_compat import QtCore, QtGui, QtWidgets

_COLORS = {
    Severity.ERROR: "#e74c3c",
    Severity.WARNING: "#e6a23c",
    Severity.INFO: "#5dade2",
}
_ICONS = {Severity.ERROR: "✖", Severity.WARNING: "⚠", Severity.INFO: "ℹ"}
_ROLE = QtCore.Qt.UserRole
_window = None


class MainWindow(MayaQWidgetDockableMixin, QtWidgets.QWidget):
    OBJECT_NAME = "MusanchesExporterWindow"

    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent=parent)
        self.setObjectName(self.OBJECT_NAME)
        self.setWindowTitle("Musanches Export Preflight")
        self.setMinimumSize(860, 480)
        self._report = None
        self._issues = []
        self._root_uuids = []
        self._tool_selection = set()   # seleção feita pela própria ferramenta
        self._scope_note = ""
        self._build_ui()

    # ---- construção ---------------------------------------------------
    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        help_label = QtWidgets.QLabel(
            "1) Escolha o destino (perfil) e o que verificar.  2) Clique em Verificar.  "
            "3) Itens com <b>Correção: Automática</b> vêm marcados com ☑ e podem ser corrigidos pelo botão; "
            "itens <b>Manual</b> precisam ser resolvidos no Maya (dê duplo clique para selecionar os objetos).")
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        top = QtWidgets.QHBoxLayout()
        top.addWidget(QtWidgets.QLabel("Perfil:"))
        self.profile_combo = QtWidgets.QComboBox()
        for key in available_profiles():
            try:
                self.profile_combo.addItem(load_profile(key).name, key)
            except Exception:
                self.profile_combo.addItem(key, key)
        top.addWidget(self.profile_combo, 1)
        top.addWidget(QtWidgets.QLabel("Verificar:"))
        self.scope_combo = QtWidgets.QComboBox()
        self.scope_combo.addItem("Só o que está selecionado no Maya", "selection")
        self.scope_combo.addItem("Cena inteira", "scene")
        self.scope_combo.setToolTip(
            "Selecionado no Maya: use a viewport ou o Outliner para escolher malhas, joints ou grupos "
            "(os filhos entram junto).\nCena inteira: ignora a seleção.")
        top.addWidget(self.scope_combo)
        layout.addLayout(top)

        buttons = QtWidgets.QHBoxLayout()
        self.btn_check = QtWidgets.QPushButton("Verificar")
        self.btn_fix_sel = QtWidgets.QPushButton("Corrigir marcados ☑")
        self.btn_fix_sel.setToolTip("Aplica a correção automática nos itens da lista que estão marcados com ☑.")
        self.btn_fix_all = QtWidgets.QPushButton("Corrigir tudo (automáticos)")
        self.btn_fix_all.setToolTip("Corrige todos os itens com 'Correção: Automática', um de cada vez, e verifica de novo.")
        self.btn_pick = QtWidgets.QPushButton("Selecionar no Maya")
        self.btn_pick.setToolTip("Seleciona no Maya os objetos do item escolhido na lista (ou dê duplo clique no item).")
        self.btn_export = QtWidgets.QPushButton("Exportar FBX…")
        self.btn_save = QtWidgets.QPushButton("Salvar relatório…")
        for b in (self.btn_check, self.btn_fix_sel, self.btn_fix_all, self.btn_pick, self.btn_export, self.btn_save):
            buttons.addWidget(b)
        layout.addLayout(buttons)

        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(["Verificação", "Correção", "Dica"])
        self.tree.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.tree.setUniformRowHeights(False)
        self.tree.setWordWrap(True)
        layout.addWidget(self.tree, 1)

        self.summary = QtWidgets.QLabel("Escolha um perfil e clique em Verificar.")
        layout.addWidget(self.summary)

        self.btn_check.clicked.connect(self.run_checks)
        self.btn_fix_sel.clicked.connect(self.fix_selected)
        self.btn_fix_all.clicked.connect(self.fix_all)
        self.btn_pick.clicked.connect(lambda: self.select_in_maya(self.tree.selectedItems()))
        self.btn_export.clicked.connect(self.export_fbx)
        self.btn_save.clicked.connect(self.save_report)
        self.tree.itemDoubleClicked.connect(lambda item, _col: self.select_in_maya([item]))

    # ---- ajudantes ----------------------------------------------------
    def _profile(self):
        return load_profile(self.profile_combo.currentData())

    @staticmethod
    def _selected_roots():
        """Objetos DAG da seleção atual: componentes viram o objeto, shapes viram o transform.
        Nós que não são objetos de cena (shaders, nós de rede) são ignorados."""
        roots = []
        for node in cmds.ls(selection=True, objectsOnly=True, long=True) or []:
            if not cmds.objectType(node, isAType="dagNode"):
                continue
            if cmds.objectType(node, isAType="shape"):
                parents = cmds.listRelatives(node, parent=True, fullPath=True) or []
                node = parents[0] if parents else node
            roots.append(node)
        return list(dict.fromkeys(roots))

    def _make_ctx(self, refresh=False):
        """Cria o contexto da cena.

        O escopo 'selecionado' guarda os objetos por UUID: clicar num problema muda a
        seleção do Maya, e renomear objetos muda os caminhos longos.
        """
        if self.scope_combo.currentData() != "selection":
            self._scope_note = "cena inteira"
            return SceneContext()
        if refresh:
            raw = cmds.ls(selection=True, long=True) or []
            if raw and set(raw) != self._tool_selection:
                roots = self._selected_roots()
                if not roots:
                    QtWidgets.QMessageBox.information(
                        self, "Musanches",
                        "A seleção atual não tem objetos de cena (por exemplo, só um material está selecionado).\n"
                        "Selecione malhas, joints ou grupos na viewport ou no Outliner.")
                    return None
                self._root_uuids = cmds.ls(roots, uuid=True) or []
        roots = []
        for uid in self._root_uuids:
            roots.extend(cmds.ls(uid, long=True) or [])
        if not roots:
            answer = QtWidgets.QMessageBox.question(
                self, "Musanches",
                "Nenhum objeto está selecionado no Maya.\n\nVerificar a cena inteira?")
            if answer != QtWidgets.QMessageBox.Yes:
                return None
            self.scope_combo.setCurrentIndex(self.scope_combo.findData("scene"))
            self._scope_note = "cena inteira"
            return SceneContext()
        self._scope_note = "%d objeto(s) selecionado(s) no Maya (e filhos)" % len(roots)
        return SceneContext(roots=roots)

    def _scope_name(self):
        return self._scope_note or self.scope_combo.currentText()

    def _run(self, refresh=False):
        ctx = self._make_ctx(refresh=refresh)
        if ctx is None:
            return None, None, None
        runner = Runner(self._profile(), ALL_CHECKS)
        report = runner.run(ctx, scope=self._scope_name())
        return ctx, runner, report

    def _show_report(self, report):
        self._report = report
        self._issues = list(report.issues)
        self._populate()

    def _populate(self):
        self.tree.clear()
        groups = {}
        for idx, issue in enumerate(self._issues):
            parent = groups.get(issue.category)
            if parent is None:
                parent = QtWidgets.QTreeWidgetItem(self.tree, [issue.category])
                font = parent.font(0)
                font.setBold(True)
                parent.setFont(0, font)
                groups[issue.category] = parent
            text = "%s %s" % (_ICONS[issue.severity], issue.message)
            fix_text = "Automática" if issue.fixable else "Manual (no Maya)"
            item = QtWidgets.QTreeWidgetItem(parent, [text, fix_text, issue.hint])
            item.setForeground(0, QtGui.QBrush(QtGui.QColor(_COLORS[issue.severity])))
            if issue.fixable:
                item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
                item.setCheckState(0, QtCore.Qt.Checked)
                item.setForeground(1, QtGui.QBrush(QtGui.QColor("#58b368")))
            else:
                item.setForeground(1, QtGui.QBrush(QtGui.QColor("#999999")))
            item.setData(0, _ROLE, idx)
            item.setToolTip(0, ", ".join(issue.nodes[:30]))
        self.tree.expandAll()
        self.tree.resizeColumnToContents(0)
        self.tree.resizeColumnToContents(1)
        c = self._report.counts()
        fixable = sum(1 for i in self._issues if i.fixable)
        self.summary.setText("%d erro(s), %d aviso(s), %d info (%d com correção automática) — perfil: %s — verificado: %s"
                             % (c["erro"], c["aviso"], c["info"], fixable,
                                self._report.profile_name, self._scope_note))

    def _items_to_issues(self, items):
        out = []
        for item in items:
            idx = item.data(0, _ROLE)
            if idx is not None:
                out.append(self._issues[idx])
        return out

    # ---- ações --------------------------------------------------------
    def run_checks(self, _checked=False, refresh=True):
        # _checked: o sinal clicked do botão envia um bool; sem isto ele virava refresh=False
        # e a seleção do Maya nunca era lida.
        _ctx, _runner, report = self._run(refresh=refresh)
        if report is not None:
            self._show_report(report)

    def select_in_maya(self, items):
        nodes = []
        for issue in self._items_to_issues(items):
            nodes.extend(issue.nodes)
        nodes = [n for n in nodes if cmds.objExists(n.split(".")[0])]
        if nodes:
            cmds.select(nodes, replace=True)
            self._tool_selection = set(cmds.ls(selection=True, long=True) or [])

    def _checked_issues(self):
        out = []
        for i in range(self.tree.topLevelItemCount()):
            group = self.tree.topLevelItem(i)
            for j in range(group.childCount()):
                item = group.child(j)
                if item.checkState(0) == QtCore.Qt.Checked:
                    out.extend(i2 for i2 in self._items_to_issues([item]) if i2.fixable)
        return out

    def fix_selected(self):
        issues = self._checked_issues()
        if not issues:
            QtWidgets.QMessageBox.information(
                self, "Musanches",
                "Nenhum item marcado para correção.\n\nClique em Verificar e deixe marcados (☑) os itens "
                "com 'Correção: Automática'. Itens 'Manual' precisam ser resolvidos no Maya.")
            return
        ctx = self._make_ctx()
        if ctx is None:
            return
        runner = Runner(self._profile(), ALL_CHECKS)
        failed = sum(0 if runner.fix(ctx, issue) else 1 for issue in issues)
        self.run_checks(refresh=False)
        if failed:
            self.summary.setText(self.summary.text() + "  (%d correção(ões) falharam)" % failed)

    def fix_all(self):
        """Corrige um problema por vez e reverifica, pois renomear/congelar muda os caminhos."""
        skipped = set()
        report = None
        for attempt in range(50):
            ctx, runner, report = self._run(refresh=(attempt == 0))
            if report is None:
                return
            todo = [i for i in report.issues if i.fixable and i.signature() not in skipped]
            if not todo:
                break
            if not runner.fix(ctx, todo[0]):
                skipped.add(todo[0].signature())
        self._show_report(report)

    def export_fbx(self):
        ctx, runner, report = self._run(refresh=True)
        if report is None:
            return
        self._show_report(report)
        if report.has_errors:
            answer = QtWidgets.QMessageBox.question(
                self, "Musanches", "Há erros na verificação. Exportar mesmo assim?")
            if answer != QtWidgets.QMessageBox.Yes:
                return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Exportar FBX", "", "FBX (*.fbx)")
        if not path:
            return
        if not path.lower().endswith(".fbx"):
            path += ".fbx"
        profile = self._profile()
        selection = self.scope_combo.currentData() == "selection"
        try:
            fbx_export.export_fbx(ctx, path, profile, selection=selection)
            if profile.fbx.get("verify_after_export", True):
                _summary, issues = fbx_export.verify_export(ctx, profile, selection=selection)
                self._issues.extend(issues)
                report.issues.extend(issues)
                self._populate()
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Musanches", "Falha ao exportar:\n%s" % exc)
            return
        self.summary.setText(self.summary.text() + " — exportado: %s" % os.path.basename(path))

    def save_report(self):
        if self._report is None:
            QtWidgets.QMessageBox.information(self, "Musanches", "Rode a verificação primeiro.")
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Salvar relatório", "", "HTML (*.html);;JSON (*.json)")
        if path:
            self._report.save(path)


def show_window():
    global _window
    control = MainWindow.OBJECT_NAME + "WorkspaceControl"
    if cmds.workspaceControl(control, query=True, exists=True):
        cmds.deleteUI(control)
    _window = MainWindow()
    _window.show(dockable=True, floating=True, retain=False)
    return _window
