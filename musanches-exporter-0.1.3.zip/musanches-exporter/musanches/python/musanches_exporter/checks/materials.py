"""Materiais: o FBX não leva shaders Arnold, e arquivos de textura podem faltar."""
from __future__ import annotations

import os
import re

from ..core.check import Check, Severity

_COLOR_ATTRS = ("baseColor", "color")


class ShaderTypeCheck(Check):
    id = "materials.shader_type"
    category = "Materiais"
    title = "Tipo de shader"

    def run(self, ctx):
        allowed = {a.lower() for a in self.profile.section("materials").get("allowed", [])}
        if not allowed:
            return []
        defaults = set(ctx.cmds.ls(defaultNodes=True) or [])
        issues, seen = [], set()
        for info in ctx.shader_info():
            if info.shader in seen:
                continue
            seen.add(info.shader)
            if info.shader_type.lower() in allowed:
                continue
            if info.shader in defaults:
                # nó padrão do Maya (lambert1, openPBR_shader1...): somente leitura
                issues.append(self.issue(
                    Severity.WARNING,
                    "Há malhas com o material padrão do Maya ('%s', tipo '%s')." % (info.shader, info.shader_type),
                    nodes=[info.shader], fixable=True,
                    hint="O material padrão não pode ser renomeado nem apagado. A correção cria um Lambert "
                         "novo ('<nome>_lambert'), copia a cor base e reatribui as malhas.",
                ))
                continue
            issues.append(self.issue(
                Severity.ERROR,
                "O material '%s' é do tipo '%s', que o FBX não transporta." % (info.shader, info.shader_type),
                nodes=[info.shader], fixable=True,
                hint="A correção troca por um Lambert com o MESMO nome (importante para o texture set), "
                     "mantendo a cor base ou a textura de cor. Demais mapas não são copiados.",
            ))
        return issues

    def fix(self, ctx, issue):
        cmds = ctx.cmds
        defaults = set(cmds.ls(defaultNodes=True) or [])
        ok = True
        for shader in issue.nodes:
            if not cmds.objExists(shader):
                continue
            try:
                if shader in defaults:
                    self._replace_default(ctx, shader)
                else:
                    self._to_lambert(cmds, shader)
            except RuntimeError:
                ok = False
        return ok

    @staticmethod
    def _color_source(cmds, shader):
        """(plug_de_origem, valor_rgb): a textura ligada à cor base, ou a cor fixa."""
        for attr in _COLOR_ATTRS:
            if cmds.attributeQuery(attr, node=shader, exists=True):
                conns = cmds.listConnections(shader + "." + attr, source=True, destination=False, plugs=True)
                if conns:
                    return conns[0], None
                return None, cmds.getAttr(shader + "." + attr)[0]
        return None, None

    @staticmethod
    def _apply_color(cmds, new, src_plug, src_val):
        if src_plug:
            cmds.connectAttr(src_plug, new + ".color", force=True)
        elif src_val:
            cmds.setAttr(new + ".color", src_val[0], src_val[1], src_val[2], type="double3")

    @staticmethod
    def _to_lambert(cmds, shader):
        sgs = cmds.listConnections(shader + ".outColor", source=False, destination=True,
                                   type="shadingEngine") or []
        src_plug, src_val = ShaderTypeCheck._color_source(cmds, shader)
        original = shader
        old = cmds.rename(shader, shader + "_old")
        new = cmds.shadingNode("lambert", asShader=True, name=original)
        for sg in sgs:
            cmds.connectAttr(new + ".outColor", sg + ".surfaceShader", force=True)
        ShaderTypeCheck._apply_color(cmds, new, src_plug, src_val)
        cmds.delete(old)

    @staticmethod
    def _replace_default(ctx, shader):
        cmds = ctx.cmds
        src_plug, src_val = ShaderTypeCheck._color_source(cmds, shader)
        new = cmds.shadingNode("lambert", asShader=True, name=shader + "_lambert")
        sg = cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name=new + "SG")
        cmds.connectAttr(new + ".outColor", sg + ".surfaceShader", force=True)
        ShaderTypeCheck._apply_color(cmds, new, src_plug, src_val)
        shapes = [i.shape for i in ctx.shader_info() if i.shader == shader]
        for shape in dict.fromkeys(shapes):
            cmds.sets(shape, edit=True, forceElement=sg)


class TexturesCheck(Check):
    id = "materials.textures"
    category = "Materiais"
    title = "Arquivos de textura"

    def run(self, ctx):
        if not self.profile.section("materials").get("check_textures", True):
            return []
        cmds = ctx.cmds
        project = cmds.workspace(query=True, rootDirectory=True) or ""
        missing = []
        for node in cmds.ls(type="file") or []:
            path = cmds.getAttr(node + ".fileTextureName") or ""
            if not path:
                continue
            probe = re.sub(r"<udim>", "1001", os.path.expandvars(path), flags=re.I)
            if not os.path.isabs(probe):
                probe = os.path.join(project, probe)
            if not os.path.exists(probe):
                missing.append(node)
        if not missing:
            return []
        return [self.issue(
            Severity.WARNING,
            "%d nó(s) file apontam para textura inexistente (a verificação cobre a cena toda)." % len(missing),
            nodes=missing)]
