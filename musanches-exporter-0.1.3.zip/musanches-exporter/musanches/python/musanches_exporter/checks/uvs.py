"""UV sets: vazios, quantidade, lightmap e UVs fora de 0-1."""
from __future__ import annotations

from ..core.check import Check, Severity

UV_TOL = 0.01   # o cilindro padrão do Maya passa de 1.0 por ~0.002: não é problema real


class UVSetsCheck(Check):
    id = "uv.sets"
    category = "UVs"
    title = "UV sets"

    def run(self, ctx):
        cfg = self.profile.section("uv")
        max_sets = int(cfg.get("max_sets", 2))
        issues = []
        single, outside = [], []
        for shape in ctx.mesh_shapes():
            node = ctx.transform_of(shape)
            sets = ctx.uv_sets(shape)
            filled = [s for s in sets if s["count"] > 0]
            empty = [s for s in sets if s["count"] == 0]

            if not filled:
                issues.append(self.issue(
                    Severity.ERROR, "'%s' não tem UVs." % node.split("|")[-1], nodes=[node]))
                continue

            if empty and len(sets) > 1:
                issues.append(self.issue(
                    Severity.WARNING,
                    "'%s' tem UV set(s) vazio(s): %s." % (node.split("|")[-1], ", ".join(s["name"] for s in empty)),
                    nodes=[node], fixable=True,
                    hint="O FBX descarta UV sets vazios; isso desloca os canais na engine.",
                    shape=shape, empty=[s["name"] for s in empty], keep=filled[0]["name"],
                ))

            if len(filled) > max_sets:
                issues.append(self.issue(
                    Severity.WARNING,
                    "'%s' tem %d UV sets com dados; o perfil usa até %d." % (node.split("|")[-1], len(filled), max_sets),
                    nodes=[node]))

            if cfg.get("want_lightmap_set") and max_sets >= 2 and len(filled) < 2:
                single.append(node)

            bbox = filled[0]["bbox"]
            if cfg.get("require_0_1") and not cfg.get("allow_udim") and bbox:
                (umin, umax), (vmin, vmax) = bbox
                if umin < -UV_TOL or vmin < -UV_TOL or umax > 1 + UV_TOL or vmax > 1 + UV_TOL:
                    outside.append(node)

        if single:
            issues.append(self.issue(
                Severity.INFO,
                "%d malha(s) com um único UV set; para lightmap, crie o UV1 ou gere na importação da engine."
                % len(single),
                nodes=single))
        if outside:
            issues.append(self.issue(
                Severity.WARNING,
                "%d malha(s) com UVs fora de 0-1 no primeiro set." % len(outside),
                nodes=outside,
                hint="Se o objeto usa UDIM de propósito, use o perfil do Substance."))
        return issues

    def fix(self, ctx, issue):
        cmds = ctx.cmds
        shape = issue.data["shape"]
        if not cmds.objExists(shape):
            return False
        with ctx.quiet():
            cmds.polyUVSet(shape, currentUVSet=True, uvSet=issue.data["keep"])
        for name in issue.data["empty"]:
            cmds.polyUVSet(shape, delete=True, uvSet=name)
        return True
