"""Histórico, transformações, faces degeneradas e n-gons."""
from __future__ import annotations

from ..core.check import Check, Severity


class HistoryCheck(Check):
    id = "geometry.history"
    category = "Geometria"
    title = "Histórico de construção"

    def run(self, ctx):
        bad = [ctx.transform_of(s) for s in ctx.mesh_shapes() if ctx.has_poly_history(s)]
        if not bad:
            return []
        return [self.issue(
            Severity.WARNING,
            "%d malha(s) com histórico de construção." % len(bad),
            nodes=bad, fixable=True,
            hint="O FBX 'lembra' o histórico. A correção apaga só o histórico não-deformer "
                 "(skin e blend shapes são preservados).",
        )]

    def fix(self, ctx, issue):
        nodes = [n for n in issue.nodes if ctx.cmds.objExists(n)]
        if nodes:
            ctx.cmds.bakePartialHistory(nodes, prePostDeformers=True)
        return True


class TransformsCheck(Check):
    id = "geometry.transforms"
    category = "Geometria"
    title = "Transformações não congeladas"

    def run(self, ctx):
        tol = float(self.profile.section("geometry").get("transform_tolerance", 1e-4))
        cmds = ctx.cmds
        loose, negative = [], []
        for shape in ctx.mesh_shapes():
            if ctx.skin_clusters(shape):
                continue  # malha com skin: a transformação do objeto não deve ser mexida
            node = ctx.transform_of(shape)
            t = cmds.getAttr(node + ".translate")[0]
            r = cmds.getAttr(node + ".rotate")[0]
            s = cmds.getAttr(node + ".scale")[0]
            if any(abs(v) > tol for v in t) or any(abs(v) > tol for v in r) \
                    or any(abs(v - 1.0) > tol for v in s):
                loose.append(node)
            if s[0] * s[1] * s[2] < 0:   # número ímpar de eixos negativos = espelhado
                negative.append(node)
        issues = []
        if loose:
            issues.append(self.issue(
                Severity.WARNING,
                "%d objeto(s) com transformação diferente de zero/1 (pivô e escala podem mudar na engine)." % len(loose),
                nodes=loose, fixable=True,
                hint="Congele as transformações (Freeze Transformations).",
            ))
        if negative:
            issues.append(self.issue(
                Severity.ERROR,
                "%d objeto(s) com escala negativa (espelhamento): normais podem sair invertidas." % len(negative),
                nodes=negative, fixable=True,
                hint="Congelar a escala negativa NÃO reverte as faces (medido no Maya 2026); "
                     "a correção congela e depois reverte as normais dos objetos espelhados.",
            ))
        return issues

    def fix(self, ctx, issue):
        cmds = ctx.cmds
        nodes = [n for n in issue.nodes if cmds.objExists(n)]
        # decidir antes de congelar: depois do freeze a escala já é 1
        mirrored = []
        for n in nodes:
            s = cmds.getAttr(n + ".scale")[0]
            if s[0] * s[1] * s[2] < 0:
                mirrored.append(n)
        if nodes:
            cmds.makeIdentity(nodes, apply=True, translate=True, rotate=True, scale=True, normal=False)
        if mirrored:
            cmds.polyNormal(mirrored, normalMode=0, constructionHistory=False)
        return True


class FacesCheck(Check):
    id = "geometry.faces"
    category = "Geometria"
    title = "Faces degeneradas e n-gons"

    def run(self, ctx):
        tol = float(self.profile.section("geometry").get("zero_area_tolerance", 1e-6))
        triangulate = bool(self.profile.fbx.get("triangulate"))
        zero, ngon = [], []
        for shape in ctx.mesh_shapes():
            stats = ctx.face_stats(shape, zero_tol=tol)
            zero.extend(stats["zero_area"])
            ngon.extend(stats["ngons"])
        issues = []
        if zero:
            issues.append(self.issue(
                Severity.WARNING,
                "%d face(s) com área ~zero (normais e tangentes inválidas; o Substance costuma reclamar)." % len(zero),
                nodes=zero,
                hint="Use Mesh > Cleanup ou remova/una os vértices sobrepostos (preservando UVs).",
            ))
        if ngon:
            issues.append(self.issue(
                Severity.INFO if triangulate else Severity.WARNING,
                "%d n-gon(s) (mais de 4 lados)%s." % (
                    len(ngon), "; serão triangulados no export" if triangulate else ""),
                nodes=ngon,
                hint="Triangule antes do bake para que o Painter e a engine usem a mesma triangulação.",
            ))
        return issues
