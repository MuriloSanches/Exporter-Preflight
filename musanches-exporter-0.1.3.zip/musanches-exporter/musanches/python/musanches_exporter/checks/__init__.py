"""Registro das verificações, na ordem em que aparecem no relatório."""
from .units_axes import UnitsCheck, UpAxisCheck
from .geometry import HistoryCheck, TransformsCheck, FacesCheck
from .uvs import UVSetsCheck
from .materials import ShaderTypeCheck, TexturesCheck
from .skeleton import (
    SingleRootCheck, RootTransformCheck, JointScaleCheck,
    MaxInfluencesCheck, BindPoseCheck, ConstraintsCheck,
)
from .blendshapes import BlendShapeOrderCheck, BlendShapeInbetweenCheck
from .naming import NamingCheck

ALL_CHECKS = [
    UnitsCheck, UpAxisCheck,
    HistoryCheck, TransformsCheck, FacesCheck,
    UVSetsCheck,
    ShaderTypeCheck, TexturesCheck,
    SingleRootCheck, RootTransformCheck, JointScaleCheck,
    MaxInfluencesCheck, BindPoseCheck, ConstraintsCheck,
    BlendShapeOrderCheck, BlendShapeInbetweenCheck,
    NamingCheck,  # por último: renomear invalida os caminhos usados pelas outras
]
