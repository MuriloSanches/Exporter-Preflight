"""Unidade e eixo da cena (problema nº 1 da pesquisa: escala errada)."""
from __future__ import annotations

from ..core.check import Check, Severity

_UNIT = {
    "cm": "cm", "centimeter": "cm", "m": "m", "meter": "m", "mm": "mm", "millimeter": "mm",
    "in": "in", "inch": "in", "ft": "ft", "foot": "ft", "yd": "yd", "yard": "yd",
}


def _norm(unit):
    return _UNIT.get(str(unit).lower(), str(unit).lower())


class UnitsCheck(Check):
    id = "scene.units"
    category = "Cena"
    title = "Unidade linear da cena"

    def run(self, ctx):
        expected = _norm(self.profile.units)
        current = _norm(ctx.cmds.currentUnit(query=True, linear=True))
        if current == expected:
            return []
        return [self.issue(
            Severity.WARNING,
            "A unidade da cena é '%s'; o perfil espera '%s'." % (current, expected),
            fixable=True,
            hint="Unidade errada é a principal causa de objetos 100x maiores ou menores na engine.",
            expected=expected,
        )]

    def fix(self, ctx, issue):
        ctx.cmds.currentUnit(linear=issue.data["expected"])
        return True


class UpAxisCheck(Check):
    id = "scene.up_axis"
    category = "Cena"
    title = "Eixo para cima da cena"

    def run(self, ctx):
        want = str(self.profile.up_axis).lower()
        current = str(ctx.cmds.upAxis(query=True, axis=True)).lower()
        if current == want:
            return []
        return [self.issue(
            Severity.INFO,
            "A cena usa %s-up; o perfil usa %s-up." % (current.upper(), want.upper()),
            hint="O exportador converte o eixo no FBX (opção Up Axis do perfil). "
                 "Confira o root do rig após exportar.",
        )]
