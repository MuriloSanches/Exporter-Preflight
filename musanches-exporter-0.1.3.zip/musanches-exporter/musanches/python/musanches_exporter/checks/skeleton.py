"""Rig: root, escala de joints, influências, bind pose e constraints."""
from __future__ import annotations

from ..core.check import Check, Severity

TOL = 1e-3


def _root_joints(ctx):
    return [j for j in ctx.joints() if not ctx.cmds.listRelatives(j, parent=True, type="joint")]


class SingleRootCheck(Check):
    id = "rig.single_root"
    category = "Rig"
    title = "Root único"

    def run(self, ctx):
        if not self.profile.section("rig").get("single_root", True):
            return []
        roots = _root_joints(ctx)
        if len(roots) <= 1:
            return []
        return [self.issue(
            Severity.ERROR,
            "Há %d hierarquias de joints separadas; a Unreal só aceita um root por skeletal mesh." % len(roots),
            nodes=roots,
            hint="Parenteie tudo a um único joint root.",
        )]


class RootTransformCheck(Check):
    id = "rig.root_transform"
    category = "Rig"
    title = "Posição e rotação do root"

    def run(self, ctx):
        cfg = self.profile.section("rig")
        issues = []
        for root in _root_joints(ctx):
            name = root.split("|")[-1]
            if cfg.get("root_at_origin"):
                pos = ctx.cmds.xform(root, query=True, worldSpace=True, translation=True)
                if any(abs(v) > TOL for v in pos):
                    issues.append(self.issue(
                        Severity.WARNING,
                        "O root '%s' não está na origem do mundo." % name, nodes=[root],
                        hint="Root fora da origem atrapalha root motion e o posicionamento do asset."))
            if cfg.get("root_zero_rotation"):
                rot = ctx.cmds.getAttr(root + ".rotate")[0]
                if any(abs(v) > TOL for v in rot):
                    issues.append(self.issue(
                        Severity.WARNING,
                        "O root '%s' tem rotação aplicada." % name, nodes=[root],
                        hint="Passe a rotação para o Joint Orient: rotações no root costumam virar giros de 90° na engine."))
        return issues


class JointScaleCheck(Check):
    id = "rig.joint_scale"
    category = "Rig"
    title = "Escala dos joints"

    def run(self, ctx):
        if not self.profile.section("rig").get("warn_non_unit_scale", True):
            return []
        bad = []
        for joint in ctx.joints():
            scale = ctx.cmds.getAttr(joint + ".scale")[0]
            if any(abs(v - 1.0) > TOL for v in scale):
                bad.append(joint)
        if not bad:
            return []
        return [self.issue(
            Severity.WARNING,
            "%d joint(s) com escala diferente de 1." % len(bad), nodes=bad,
            hint="Escala em joints se comporta de forma diferente fora do Maya (Scale Compensate).")]


class MaxInfluencesCheck(Check):
    id = "rig.max_influences"
    category = "Rig"
    title = "Influências por vértice"

    def run(self, ctx):
        limit = int(self.profile.section("rig").get("max_influences", 4))
        issues = []
        for shape in ctx.mesh_shapes():
            stats = ctx.influence_stats(shape, limit)
            if stats and stats["over"]:
                node = ctx.transform_of(shape)
                issues.append(self.issue(
                    Severity.WARNING,
                    "'%s': %d vértice(s) com mais de %d influências (máximo encontrado: %d)."
                    % (node.split("|")[-1], stats["over"], limit, stats["max"]),
                    nodes=[node],
                    hint="Use Skin > Prune Small Weights ou limite as influências antes de exportar."))
        return issues


class BindPoseCheck(Check):
    id = "rig.bind_pose"
    category = "Rig"
    title = "Bind pose"

    def run(self, ctx):
        cmds = ctx.cmds
        bad = []
        for shape in ctx.mesh_shapes():
            for skin in ctx.skin_clusters(shape):
                has_pose = cmds.attributeQuery("bindPose", node=skin, exists=True) and \
                    cmds.listConnections(skin + ".bindPose", source=True, destination=False)
                if not has_pose:
                    bad.append(ctx.transform_of(shape))
        if not bad:
            return []
        return [self.issue(
            Severity.WARNING,
            "%d malha(s) com skin sem bind pose conectada." % len(bad), nodes=list(dict.fromkeys(bad)),
            hint="A UE5 (Interchange) avisa de bind pose inválida e refaz o skin pela pose do tempo zero.")]


class ConstraintsCheck(Check):
    id = "rig.constraints"
    category = "Rig"
    title = "Constraints"

    def run(self, ctx):
        if self.profile.fbx.get("constraints"):
            return []
        found = ctx.constraints()
        if not found:
            return []
        return [self.issue(
            Severity.INFO,
            "%d constraint(s) na seleção; o FBX não as leva para a engine." % len(found), nodes=found,
            hint="Em jogos, armas e acessórios costumam virar sockets criados na engine.")]
