"""Nomes de malhas, joints e materiais (o nome do material vira texture set no Substance)."""
from __future__ import annotations

import re

from ..core.check import Check, Severity


def _short(node):
    return node.split("|")[-1]


class NamingCheck(Check):
    id = "naming.names"
    category = "Nomes"
    title = "Nomes válidos"

    def run(self, ctx):
        pattern = self.profile.section("naming").get("pattern", "")
        if not pattern:
            return []
        rx = re.compile(pattern)
        candidates = [ctx.transform_of(s) for s in ctx.mesh_shapes()]
        candidates += ctx.joints()
        candidates += ctx.shader_nodes()
        bad = [n for n in dict.fromkeys(candidates) if not rx.match(_short(n))]
        if not bad:
            return []
        return [self.issue(
            Severity.WARNING,
            "%d nome(s) fora do padrão do perfil (espaços, acentos, namespaces...)." % len(bad),
            nodes=bad, fixable=True,
            hint="Namespaces e caracteres especiais viram problemas de nome de asset e de texture set.",
        )]

    def fix(self, ctx, issue):
        cmds = ctx.cmds
        ok = True
        # filhos primeiro, para não invalidar os caminhos dos pais
        for node in sorted(issue.nodes, key=lambda n: n.count("|"), reverse=True):
            if not cmds.objExists(node):
                continue
            new = re.sub(r"[^A-Za-z0-9_]", "_", _short(node))
            try:
                cmds.rename(node, new)
            except RuntimeError:
                ok = False  # por exemplo, nó vindo de referência
        return ok
