"""Blend shapes: ordem dos deformers e inbetweens."""
from __future__ import annotations

from ..core.check import Check, Severity


class BlendShapeOrderCheck(Check):
    id = "blendshapes.order"
    category = "Blend shapes"
    title = "Ordem blend shape x skin"

    def run(self, ctx):
        if not self.profile.section("blendshapes").get("require_pre_deformation", True):
            return []
        cmds = ctx.cmds
        bad = []
        for shape in ctx.mesh_shapes():
            history = cmds.listHistory(shape, pruneDagObjects=True) or []
            types = [cmds.nodeType(n) for n in history]
            skin_idx = [i for i, t in enumerate(types) if t == "skinCluster"]
            bs_idx = [i for i, t in enumerate(types) if t == "blendShape"]
            # o histórico começa pelo nó mais próximo da malha: blend shape antes do skin
            # na lista significa que ele é avaliado DEPOIS do skin (pós-deformação)
            if skin_idx and bs_idx and min(bs_idx) < min(skin_idx):
                bad.append(ctx.transform_of(shape))
        if not bad:
            return []
        return [self.issue(
            Severity.WARNING,
            "%d malha(s) com blend shape avaliado depois do skin (pós-deformação)." % len(bad),
            nodes=bad,
            hint="Há relatos de blend shapes quebrando no FBX nesse caso. Recrie-os com "
                 "'Pre-deformation' e faça o bind ao esqueleto depois.")]


class BlendShapeInbetweenCheck(Check):
    id = "blendshapes.inbetweens"
    category = "Blend shapes"
    title = "Inbetweens"

    def run(self, ctx):
        if not self.profile.section("blendshapes").get("warn_inbetweens", True):
            return []
        cmds = ctx.cmds
        found = []
        nodes = []
        for shape in ctx.mesh_shapes():
            history = cmds.listHistory(shape) or []
            nodes.extend(cmds.ls(history, type="blendShape") or [] if history else [])
        for node in dict.fromkeys(nodes):
            try:
                groups = cmds.getAttr(node + ".inputTarget[0].inputTargetGroup", multiIndices=True) or []
                for g in groups:
                    plug = "%s.inputTarget[0].inputTargetGroup[%d].inputTargetItem" % (node, g)
                    items = cmds.getAttr(plug, multiIndices=True) or []
                    if len(items) > 1:
                        found.append(node)
                        break
            except RuntimeError:
                continue
        if not found:
            return []
        return [self.issue(
            Severity.WARNING,
            "%d blend shape(s) com inbetweens." % len(found), nodes=found,
            hint="Relatos da comunidade indicam que a Unreal ignora inbetweens do Maya; "
                 "considere dividir em targets separados.")]
