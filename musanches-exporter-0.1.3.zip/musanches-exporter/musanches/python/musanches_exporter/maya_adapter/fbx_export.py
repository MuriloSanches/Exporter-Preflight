"""Aplica um perfil às opções do exportador FBX do Maya e exporta.

Usa os comandos MEL do plugin FBX (FBXExport*), em vez de reimplementar o
exportador. Confira os nomes dos comandos na sua versão do Maya se algum
falhar: o plugin FBX pode variar entre versões.
"""
from __future__ import annotations

import os
import shutil
import tempfile

from ..core import fbx_reader

# chave do perfil -> comando MEL que recebe "-v true|false"
_BOOL_COMMANDS = {
    "smoothing_groups": "FBXExportSmoothingGroups",
    "tangents": "FBXExportTangents",
    "triangulate": "FBXExportTriangulate",
    "skins": "FBXExportSkins",
    "shapes": "FBXExportShapes",
    "constraints": "FBXExportConstraints",
    "input_connections": "FBXExportInputConnections",
    "embed_media": "FBXExportEmbeddedTextures",
    "bake_animation": "FBXExportBakeComplexAnimation",
    "cameras": "FBXExportCameras",
    "lights": "FBXExportLights",
    "ascii": "FBXExportInAscii",
}


def _mel():
    from maya import mel
    return mel


def apply_profile(profile, overrides=None, cmds=None):
    """Reinicia as opções do FBX e aplica as do perfil (com overrides opcionais)."""
    mel = _mel()
    opts = dict(profile.fbx)
    opts.update(overrides or {})

    mel.eval("FBXResetExport")
    for key, command in _BOOL_COMMANDS.items():
        if key in opts:
            mel.eval("%s -v %s" % (command, "true" if opts[key] else "false"))
    if opts.get("up_axis"):
        mel.eval("FBXExportUpAxis %s" % opts["up_axis"])
    if opts.get("convert_unit"):
        mel.eval("FBXExportConvertUnitString %s" % opts["convert_unit"])
    if opts.get("version"):
        mel.eval("FBXExportFileVersion -v %s" % opts["version"])

    if opts.get("bake_animation"):
        if cmds is None:
            from maya import cmds
        start = int(cmds.playbackOptions(query=True, minTime=True))
        end = int(cmds.playbackOptions(query=True, maxTime=True))
        mel.eval("FBXExportBakeComplexStart -v %d" % start)
        mel.eval("FBXExportBakeComplexEnd -v %d" % end)


def _export_current(path, selection):
    path = path.replace("\\", "/").replace('"', "")
    flag = " -s" if selection else ""
    _mel().eval('FBXExport -f "%s"%s' % (path, flag))


def export_fbx(ctx, path, profile, selection=True):
    """Exporta `ctx.roots` (ou a cena inteira) com as opções do perfil."""
    cmds = ctx.cmds
    previous = cmds.ls(selection=True, long=True) or []
    try:
        if selection:
            if not ctx.roots:
                raise RuntimeError("Nada selecionado para exportar.")
            cmds.select(ctx.roots, replace=True)
        apply_profile(profile, cmds=cmds)
        _export_current(path, selection)
    finally:
        if previous:
            cmds.select(previous, replace=True)
        else:
            cmds.select(clear=True)
    return path


def verify_export(ctx, profile, selection=True):
    """Exporta uma cópia ASCII temporária e confere o que foi gravado contra o perfil."""
    cmds = ctx.cmds
    tmp = tempfile.mkdtemp(prefix="musanches_")
    path = os.path.join(tmp, "verify.fbx")
    previous = cmds.ls(selection=True, long=True) or []
    try:
        if selection and ctx.roots:
            cmds.select(ctx.roots, replace=True)
        apply_profile(profile, overrides={"ascii": True}, cmds=cmds)
        _export_current(path, selection)
        summary = fbx_reader.read_fbx(path)
        return summary, fbx_reader.verify_summary(summary, profile)
    finally:
        if previous:
            cmds.select(previous, replace=True)
        else:
            cmds.select(clear=True)
        shutil.rmtree(tmp, ignore_errors=True)
