"""Única camada que fala com o Maya (maya.cmds, OpenMaya 2.0 e MEL)."""
