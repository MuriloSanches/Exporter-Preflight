"""SceneContext: consultas à cena usadas pelas verificações.

As verificações só enxergam este objeto (e ctx.cmds para leituras simples),
o que permite testá-las fora do Maya com um dublê.
"""
from __future__ import annotations

import contextlib
from collections import namedtuple

ShaderInfo = namedtuple("ShaderInfo", "shape sg shader shader_type")

_HISTORY_TYPES = ("polyModifier", "polyCreator", "polyBase")


class SceneContext(object):
    def __init__(self, cmds=None, roots=None):
        if cmds is None:
            from maya import cmds as maya_cmds
            cmds = maya_cmds
        self.cmds = cmds
        self.roots = list(roots or [])   # vazio = cena inteira
        self._nodes = None

    # ---- coleta -------------------------------------------------------
    def nodes(self):
        if self._nodes is None:
            cmds = self.cmds
            if not self.roots:
                self._nodes = cmds.ls(dag=True, long=True) or []
            else:
                found = []
                for root in self.roots:
                    found.append(root)
                    found.extend(cmds.listRelatives(root, allDescendents=True, fullPath=True) or [])
                self._nodes = list(dict.fromkeys(found))
        return self._nodes

    def _ls(self, **kwargs):
        nodes = self.nodes()
        if not nodes:
            return []
        return self.cmds.ls(nodes, long=True, **kwargs) or []

    def mesh_shapes(self):
        return self._ls(type="mesh", noIntermediate=True)

    def joints(self):
        return self._ls(type="joint")

    def constraints(self):
        return self._ls(type="constraint")

    def transform_of(self, shape):
        parents = self.cmds.listRelatives(shape, parent=True, fullPath=True) or []
        return parents[0] if parents else shape

    def selection(self):
        return self.cmds.ls(selection=True, long=True) or []

    # ---- deformers e histórico ----------------------------------------
    def skin_clusters(self, shape):
        hist = self.cmds.listHistory(shape) or []
        if not hist:
            return []
        return self.cmds.ls(hist, type="skinCluster") or []

    def has_poly_history(self, shape):
        cmds = self.cmds
        for node in cmds.listHistory(shape, pruneDagObjects=True) or []:
            inherited = cmds.nodeType(node, inherited=True) or []
            if any(t in inherited for t in _HISTORY_TYPES):
                return True
        return False

    # ---- materiais ----------------------------------------------------
    def shader_info(self):
        cmds = self.cmds
        out = []
        for shape in self.mesh_shapes():
            seen = set()
            for sg in cmds.listConnections(shape, type="shadingEngine") or []:
                if sg in seen:
                    continue
                seen.add(sg)
                shaders = cmds.listConnections(sg + ".surfaceShader", source=True, destination=False) or []
                for shader in shaders:
                    out.append(ShaderInfo(shape, sg, shader, cmds.nodeType(shader)))
        return out

    def shader_nodes(self):
        return list(dict.fromkeys(info.shader for info in self.shader_info()))

    # ---- UVs ----------------------------------------------------------
    @contextlib.contextmanager
    def quiet(self):
        """Mudanças feitas só para ler dados não entram na fila de undo."""
        self.cmds.undoInfo(stateWithoutFlush=False)
        try:
            yield
        finally:
            self.cmds.undoInfo(stateWithoutFlush=True)

    def uv_sets(self, shape):
        """Lista [{'name', 'count', 'bbox'}] de cada UV set (bbox = ((umin,umax),(vmin,vmax)))."""
        cmds = self.cmds
        names = cmds.polyUVSet(shape, query=True, allUVSets=True) or []
        current = (cmds.polyUVSet(shape, query=True, currentUVSet=True) or [None])[0]
        out = []
        with self.quiet():
            try:
                for name in names:
                    cmds.polyUVSet(shape, currentUVSet=True, uvSet=name)
                    count = int(cmds.polyEvaluate(shape, uvcoord=True) or 0)
                    bbox = cmds.polyEvaluate(shape, boundingBox2d=True) if count else None
                    out.append({"name": name, "count": count, "bbox": bbox})
            finally:
                if current:
                    cmds.polyUVSet(shape, currentUVSet=True, uvSet=current)
        return out

    # ---- faces e skin (OpenMaya 2.0) ----------------------------------
    def face_stats(self, shape, zero_tol=1e-6, limit=500):
        """Faces de área ~zero e n-gons (mais de 4 lados), como nomes de componente."""
        from maya.api import OpenMaya as om

        sel = om.MSelectionList()
        sel.add(shape)
        it = om.MItMeshPolygon(sel.getDagPath(0))
        zero, ngon = [], []
        while not it.isDone():
            idx = it.index()
            if it.polygonVertexCount() > 4 and len(ngon) < limit:
                ngon.append("%s.f[%d]" % (shape, idx))
            if it.getArea(om.MSpace.kObject) < zero_tol and len(zero) < limit:
                zero.append("%s.f[%d]" % (shape, idx))
            it.next()
        return {"zero_area": zero, "ngons": ngon}

    def influence_stats(self, shape, limit, eps=1e-4):
        """Quantos vértices usam mais de `limit` influências. None se a malha não tem skin."""
        skins = self.skin_clusters(shape)
        if not skins:
            return None
        from maya.api import OpenMaya as om
        from maya.api import OpenMayaAnim as oma

        sel = om.MSelectionList()
        sel.add(shape)
        sel.add(skins[0])
        dag = sel.getDagPath(0)
        skin = oma.MFnSkinCluster(sel.getDependNode(1))
        num = om.MFnMesh(dag).numVertices
        comp_fn = om.MFnSingleIndexedComponent()
        comp = comp_fn.create(om.MFn.kMeshVertComponent)
        comp_fn.setCompleteData(num)
        weights, n_infl = skin.getWeights(dag, comp)
        max_found = over = 0
        for v in range(num):
            base = v * n_infl
            count = sum(1 for i in range(n_infl) if weights[base + i] > eps)
            max_found = max(max_found, count)
            if count > limit:
                over += 1
        return {"max": max_found, "over": over, "vertices": num}

    # ---- undo ---------------------------------------------------------
    @contextlib.contextmanager
    def undo_chunk(self, name="musanches"):
        self.cmds.undoInfo(openChunk=True, chunkName=name)
        try:
            yield
        finally:
            self.cmds.undoInfo(closeChunk=True)
