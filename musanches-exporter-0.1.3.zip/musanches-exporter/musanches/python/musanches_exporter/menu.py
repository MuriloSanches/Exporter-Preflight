"""Menu 'Musanches' na barra principal do Maya."""
from maya import cmds

MENU = "MusanchesMenu"


def install():
    if cmds.about(batch=True):
        return
    if cmds.menu(MENU, query=True, exists=True):
        cmds.deleteUI(MENU)
    cmds.menu(MENU, label="Musanches", parent="MayaWindow", tearOff=True)
    cmds.menuItem(label="Export Preflight…", parent=MENU,
                  annotation="Valida, corrige e exporta FBX para Unreal, Unity e Substance",
                  command="import musanches_exporter; musanches_exporter.show()")
