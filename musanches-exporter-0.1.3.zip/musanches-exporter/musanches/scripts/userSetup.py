"""Registra o menu Musanches ao iniciar o Maya (carregado pelo módulo)."""
from maya import cmds


def _install_musanches_menu():
    try:
        from musanches_exporter import menu
        menu.install()
    except Exception as exc:  # nunca atrapalhar a abertura do Maya
        print("[Musanches] não foi possível criar o menu: %s" % exc)


cmds.evalDeferred(_install_musanches_menu, lowestPriority=True)
