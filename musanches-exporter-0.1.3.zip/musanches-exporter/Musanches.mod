+ Musanches 0.1.3 musanches
PYTHONPATH +:= python
MAYA_SCRIPT_PATH +:= scripts
